
import numpy as np
import scipy.io as sio
import scipy.sparse as ss

with open('name.txt', 'r') as fid:
    names = fid.readlines()

for i, n in enumerate(names):
    oName = 'BTER_{}'.format(i+1)
    fName = n.rstrip()
    np.save(oName, sio.loadmat(fName)['G_bter'].todense())
